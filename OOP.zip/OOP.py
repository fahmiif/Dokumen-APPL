from datetime import date
import random
import time

class customer:
    def nama():
        nama =str(input('nama customer: '))
    def alamat():
        alamat=str(input('alamat: '))
    def nomor():
        nomor=int(input('nomor tlp: '))
    def id():
        Id =('Id customer: ',random.randint(1,1000))
    
class admin:
    def namaadmin():
        nama=str(input('nama admin: '))
    def nomoradmin():
        nomor=int(input('nomor tlp: '))
    def idadmin():
        Id = ('Id admin: ',random.randint(1,3))
    
class villa():
    return idvilla()
    return namavilla()
    return alamatvilla()
    return nomorvilla()
    return descvilla()
    return hargavilla()
    
class owner():
    def namaowner():
        nama=str(input('nama customer: '))
    def alamatowner():
        alamat=str(input('alamat: '))
    def nomorowner():
        nomor=int(input('nomor tlp: '))
    def idowner():
        Id = ('Id owner: ',random.randint(1,1000))
    def namavilla():
        nama=str(input('nama villa: '))
    def alamatvilla():
        alamat=str(input('alamat: '))
    def nomorvilla():
        nomor=int(input('nomor tlp: '))
    def descvilla():
        desc=str(input('deskripsi villa: '))
    def hargavilla():
        harga=int(input('harga: '))
    def idvilla():
        Id = ('Id villa: ',random.randint(1,1000))


class transaksi:
    def waktutransaksi():
        waktutransaksi= time.asctime(time.localtime(time.time()))

    def checkinout():
        tahun1=int(input('tahun checkin: '))
        bulan1=int(input('bulan checkin: '))
        tanggal1=int(input('tanggal checkin: '))
        tahun2=int(input('tahun checkout: '))
        bulan2=int(input('bulan checkout: '))
        tanggal2=int(input('tanggal checkout: '))
        tgl1 = date(year = tahun1, month = bulan1, day = tanggal1)
        tgl2 = date(year = tahun2, month = bulan2, day = tanggal2)
        selisih = tgl2 - tgl1
        totalharga= selisih*villa()
        return('checkin: ',tgl1)
        return('checkout: ',tgl2)
        return('waktu transaksi: ',waktutransaksi)
        return('lama menginap = ', selisih.days, ' hari')
        return('total pembayaran= ',totalharga)






